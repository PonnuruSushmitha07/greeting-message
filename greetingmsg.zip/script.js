// script.js

// Function to determine the appropriate greeting
function displayGreeting() {
    const now = new Date();
    const hours = now.getHours();
    let greeting;

    if (hours < 12) {
        greeting = "Good Morning!";
    } else if (hours < 18) {
        greeting = "Good Afternoon!";
    } else {
        greeting = "Good Evening!";
    }

    // Display the greeting in an alert box
    alert(greeting);
}

// Call the function when the page loads
displayGreeting();
